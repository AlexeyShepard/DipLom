<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class PeopleAccessInterim extends Model
{
    /**
    * Таблица, связанная с моделью.
    *
    * @var string
    */
    protected $table = 'Lom_PeopleAccessInterim';

  /**
    * @var bool
    */
    public $timestamps = false;
}
