<?php

return [
    'Peoples' => 'Peoples',
    'SurName' => 'Surname',
    'FirstName' => 'First name',
    'PatronymicName' => 'Patronymic name',
    'Login' => 'Login',
    'Password' => 'Password',
    'DateTimeCreate' => 'Registration date',
    'ActivityStatus' => 'Activity status',
    'ActualPincode' => 'Actual Pincode',
    'PinCodeGenerationTime' => 'Pincode generation date',
    'PinCodeEndTime' => 'Pincode expiration',
    'Phonenumber' => 'Phonenumber',
    'Email' => 'Email',

    'Access' => 'Access',
    'Option' => 'Oprions',
    'Comment' => 'Name',
    'AddAccess' => 'Add access',

    'Notifications' => 'Notifications',
    'SFP' => 'Full name',
    'Content' => 'Content',
    'DateTimeEvent' => 'Event date',

    'EventsLogs' => 'Events log',
    'Result' => 'Result',
    'Success' => 'Success',
    'Error'=> 'Error',

    'Tools' => 'Tools',
    'PinCodeGeneration' => 'Generate Pincode',
    'Launch' => 'Launch',

    'AccessList' => 'Access list',

    'Organization' => 'Organization',
    'Name' => 'Name',
    'Parent' => 'Parent organization',

    'Organization' => 'Organization',
    'AddOrganization' => 'Add organization'
];

?>