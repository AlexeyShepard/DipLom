<h3>{{ $pinCodeGeneration }}</h3>

<div class="btn-group grid-create-btn" style="margin-right: 10px">
  <a href="{{ $generatePinCodeUrl }}" class="btn btn-sm btn-primary" title="{{ $launch }}">
    <i class="fa"></i><span class="hidden-xs">&nbsp;&nbsp;{{ $launch }}</span>
  </a>
</div>