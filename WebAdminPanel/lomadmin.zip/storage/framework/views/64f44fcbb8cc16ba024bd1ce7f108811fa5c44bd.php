<h3><?php echo e($pinCodeGeneration, false); ?></h3>

<div class="btn-group grid-create-btn" style="margin-right: 10px">
  <a href="<?php echo e($generatePinCodeUrl, false); ?>" class="btn btn-sm btn-primary" title="<?php echo e($launch, false); ?>">
    <i class="fa"></i><span class="hidden-xs">&nbsp;&nbsp;<?php echo e($launch, false); ?></span>
  </a>
</div><?php /**PATH C:\xampp\htdocs\lomadmin\resources\views/tools.blade.php ENDPATH**/ ?>