<?php

namespace App\Admin\Controllers;

use Encore\Admin\Controllers\AdminController;
use Encore\Admin\Layout\Content;
use Encore\Admin\Form;
use Encore\Admin\Grid;
use Encore\Admin\Show;
use GuzzleHttp\Client;

class ToolController extends AdminController
{
    public function index(Content $content)
    {
        $generatePinCodeUrl = url('admin/tools/generate-pincode');
        
        return $content
            ->title(trans('base.Tools'))
            ->body(view('tools', ['generatePinCodeUrl' => $generatePinCodeUrl,
                                  'launch' => trans('base.Launch'),                                         
                                  'pinCodeGeneration' => trans('base.PinCodeGeneration')]));
    } 

    public function generatePinCode(Content $content)
    {
        try
        {
            $client = new Client(['base_uri' => 'http://u0828948admin.isp.regruhosting.ru/api/web/']);

            $PeoplesJson = $client->request('GET', 'peoples');

            $Peoples = json_decode($PeoplesJson->getBody());
            
            foreach($Peoples as $People)
            {
                $body = "id_People=". $People->id ."&id_EventType=110&HumanOrder=%u041D%u0435%u0442";       

                $responce = $client->request('POST', 'events-handlings', [
                    'headers' => [
                        'Content-Type' => 'application/x-www-form-urlencoded'
                    ],
                    'body' => $body
                ]);
            }

            admin_success('Успех!', 'Пин-коды были сгенерированы успешно!');
        }
        catch (Exception $e)
        {
            admin_error('Провал!', 'Что-то пошло не так =( '. $e->getMessage());
        }
        

        return redirect(url('admin/tools'));
    }
}
